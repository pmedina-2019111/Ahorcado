/*
 * Nombre: Pedro Emilio Medina de Paz
 * Carné: 2019111
 * Código: Tecníco IN5BM
 * Fecha de Creación: 12/04/2023
 * Fecha de Modificacion: 13/04/2023, 18/04/2023, 19/04/2023, 24/04/2023, 25/04/2023
 * Fecha de Finalizacion: 27/04/23

 */
package org.pedromedina.main;

import javafx.scene.image.Image;
import java.io.InputStream;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.pedromedina.bean.ProductosHasPlatos;
import org.pedromedina.bean.ServiciosHasEmpleado;
import org.pedromedina.controller.EmpleadoController;
import org.pedromedina.controller.EmpresaController;
import org.pedromedina.controller.LoginController;
import org.pedromedina.controller.MenuPrincipalController;
import org.pedromedina.controller.PlatoController;
import org.pedromedina.controller.PresupuestoController;
import org.pedromedina.controller.ProductoController;
import org.pedromedina.controller.ProductosHasPlatosController;
import org.pedromedina.controller.ProgramadorController;
import org.pedromedina.bean.ServicioController;
import org.pedromedina.controller.ServicioHasPlatosController;
import org.pedromedina.controller.ServiciosHasEmpleadoController;
import org.pedromedina.controller.TipoEmpleadoController;
import org.pedromedina.controller.TipoPlatoController;
import org.pedromedina.controller.UsuarioController;

/**
 *
 * @author informatica
 */
public class Principal extends Application {
    private final String PAQUETE_VISTA = "/org/pedromedina/view/";
    private Stage escenarioPrincipal;
    private Scene escena;
    
    @Override
    public void start(Stage escenarioPrincipal) throws Exception{
        this.escenarioPrincipal = escenarioPrincipal;
        this.escenarioPrincipal.setTitle("Tony's Kinal 2023");
        escenarioPrincipal.getIcons().add(new Image("/org/pedromedina/image/Logo2.png"));
        /*Parent root = FXMLLoader.load(getClass().getResource("/org/pedromedina/view/MenuPrincipalView.fxml"));
        //Parent root = FXMLLoader.load(getClass().getResource("/org/pedromedina/view/ProgramadorView.fxml"));
        //Parent root = FXMLLoader.load(getClass().getResource("/org/pedromedina/view/EmpresaView.fxml"));
        Scene escena = new Scene(root);
        escenarioPricipal.setScene(escena);*/
        login();
        escenarioPrincipal.show();
    }

    public void menuPrincipal(){
        
        try{
            MenuPrincipalController menu = (MenuPrincipalController)cambiarEscena ("MenuPrincipalView.fxml",370,372);
            menu.setEscenarioPrincipal(this);
        }catch (Exception e){
            e.printStackTrace(); 
        }
    }
    
    public void ventanaProgramador(){
        
        try{
            ProgramadorController programador = (ProgramadorController) cambiarEscena("ProgramadorView.fxml",600,400);
            programador.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();   
        }
    }
    
    public void ventanaEmpresa(){
        
        try{
            EmpresaController empresa = (EmpresaController) cambiarEscena("EmpresaView.fxml",590,400);
            empresa.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();   
        }
    }
    
    public void ventanaProducto(){
        
        try{
            ProductoController producto = (ProductoController) cambiarEscena("ProductoView.fxml",590,400);
            producto.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();   
        }
    }
    
    public void ventanaTipoEmpleado(){
        
        try{
            TipoEmpleadoController tipoEmpleado = (TipoEmpleadoController) cambiarEscena("TipoEmpleadoView.fxml",590,400);
            tipoEmpleado.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();   
        }
    }
    
    public void ventanaTipoPlato(){
        
        try{
            TipoPlatoController tipoPlato = (TipoPlatoController) cambiarEscena("TipoPlatoView.fxml",590,400);
            tipoPlato.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();   
        }
    }
    
    public void ventanaPresupuesto(){
        try
        {
            PresupuestoController presupuesto = (PresupuestoController) cambiarEscena("PresupuestoView.fxml", 590, 400);
            presupuesto.setEscenarioPrincipal(this);
        } catch (Exception e)
        {
            e.printStackTrace();
        }    
    }
    
    public void ventanaEmpleado(){
        try
        {
            EmpleadoController empleado = (EmpleadoController) cambiarEscena("EmpleadoView.fxml", 678, 432);
            empleado.setEscenarioPrincipal(this);
        } catch (Exception e)
        {
            e.printStackTrace();
        }    
    }
    
    public void login(){
        try{
            LoginController login = (LoginController) cambiarEscena("LoginView.fxml", 590 , 400);
            login.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaUsuario(){
        try{
            UsuarioController usuarioController = (UsuarioController) cambiarEscena("UsuarioView.fxml", 590, 400);
            usuarioController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        launch(args);
    }
    
    public void ventanaPlato(){
        try{
            PlatoController platoController = (PlatoController) cambiarEscena("PlatoView.fxml", 678, 432);
            platoController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaServicio(){
        try{
            ServicioController  servicioController = (ServicioController) cambiarEscena("ServicioView.fxml", 678, 432);
            servicioController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }   
    }
    
    public void ventanaProductosHasPlatos(){
        try{
            ProductosHasPlatosController productoshasPlatos = (ProductosHasPlatosController) cambiarEscena("ProductosHasPlatosView.fxml", 590, 400);
            productoshasPlatos.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaServiciosHasEmpleado(){
        try{
            ServiciosHasEmpleadoController serviciosHasEmpleado = (ServiciosHasEmpleadoController) cambiarEscena ("ServiciosHasEmpleadosView.fxml", 590, 400);
            serviciosHasEmpleado.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaServiciosHasPlatos(){
        try{
            ServicioHasPlatosController servicioHasPlatos = (ServicioHasPlatosController) cambiarEscena ("ServiciosHasPlatosView.fxml", 590, 400);
            servicioHasPlatos.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public Initializable cambiarEscena (String fxml, int ancho, int alto) throws Exception{
    
        Initializable resultado = null;
        FXMLLoader cargadorFXML = new FXMLLoader();
        InputStream archivo = Principal.class.getResourceAsStream(PAQUETE_VISTA+fxml);
        cargadorFXML.setBuilderFactory(new JavaFXBuilderFactory());
        cargadorFXML.setLocation(Principal.class.getResource(PAQUETE_VISTA+fxml));
        escena = new Scene((AnchorPane)cargadorFXML.load(archivo),ancho,alto);
        escenarioPrincipal.setScene(escena);
        escenarioPrincipal.sizeToScene();
        resultado = (Initializable)cargadorFXML.getController();
        return resultado;
    }
    
}