
package org.pedromedina.controller;

import com.jfoenix.controls.JFXTimePicker;
import eu.schudt.javafx.controls.calendar.DatePicker;
import java.net.URL;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javax.swing.JOptionPane;
import org.pedromedina.bean.Empleado;
import org.pedromedina.bean.Servicio;
import org.pedromedina.bean.ServiciosHasEmpleado;
import org.pedromedina.db.Conexion;
import org.pedromedina.main.Principal;

public class ServiciosHasEmpleadoController implements Initializable{
    
    private Principal escenarioPrincipal;
    private enum operaciones {
        GUARDAR, ELIMINAR, ACTUALIZAR, NINGUNO
    }
    private operaciones tipoDeOperacion = operaciones.NINGUNO;
    private ObservableList<ServiciosHasEmpleado> listaServicioHasEmpleado;
    private ObservableList<Empleado> listaHasEmpleadito;
    private ObservableList<Servicio> listaHasServicito;
    private DatePicker fecha;
    @FXML private TextField txtServicios_codigoServicio;
    @FXML private TextField txtServicio_LugarEvento;
    @FXML private ComboBox cmbServicio_codigoServicio;
    @FXML private ComboBox cmbServicio_codigoEmpleado;
    @FXML private Button btnAgregar;  
    @FXML private Button btnReporte;    
    @FXML private GridPane grpServicios_FechaServicio;   
    @FXML private JFXTimePicker JFXHoraEvento;
    @FXML private TableView tblServiciosHasEmpleado;
    @FXML private TableColumn colServicio_codigoServicio;
    @FXML private TableColumn colServicio_codigoServiciop;
    @FXML private TableColumn colServicio_codigoEmpleado;
    @FXML private TableColumn colServicio_FechaEvento;
    @FXML private TableColumn colServicio_HoraEvento;
    @FXML private TableColumn colServicio_LugarEvento;  
    @FXML private ImageView imgAgregar;
    @FXML private ImageView imgReporte;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.cargarDatos();
        fecha = new DatePicker(Locale.ENGLISH);
        fecha.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
        fecha.getCalendarView().todayButtonTextProperty().set("Today");
        fecha.getCalendarView().setShowWeeks(true);
        fecha.getStylesheets().add("/org/pedromedina/resource/TonysKinal.css");
        grpServicios_FechaServicio.add(fecha, 3, 1);
        fecha.setAlignment(Pos.CENTER);
        cmbServicio_codigoServicio.setItems(getServicio());
        cmbServicio_codigoEmpleado.setItems(getEmpleado());
    }
    public void cargarDatos() {
        tblServiciosHasEmpleado.setItems(getServiciosHasEmpleado());
        colServicio_codigoServicio.setCellValueFactory(new PropertyValueFactory<ServiciosHasEmpleado, Integer>("Servicios_codigoServicio"));
        colServicio_codigoServiciop.setCellValueFactory(new PropertyValueFactory<ServiciosHasEmpleado, Integer>("codigoServicio"));
        colServicio_codigoEmpleado.setCellValueFactory(new PropertyValueFactory<ServiciosHasEmpleado, Integer>("codigoEmpleado"));
        colServicio_FechaEvento.setCellValueFactory(new PropertyValueFactory<ServiciosHasEmpleado, Date>("fechaEvento"));
        colServicio_HoraEvento.setCellValueFactory(new PropertyValueFactory<ServiciosHasEmpleado, String>("horaEvento"));
        colServicio_LugarEvento.setCellValueFactory(new PropertyValueFactory<ServiciosHasEmpleado, String>("lugarEvento"));
    } 
    public void seleccionarElemento() {
        txtServicios_codigoServicio.setText(String.valueOf(((ServiciosHasEmpleado) tblServiciosHasEmpleado.getSelectionModel().getSelectedItem()).getServicios_codigoServicio()));
        cmbServicio_codigoServicio.getSelectionModel().select(buscarServicio(((ServiciosHasEmpleado) tblServiciosHasEmpleado.getSelectionModel().getSelectedItem()).getCodigoServicio()));
        cmbServicio_codigoEmpleado.getSelectionModel().select(buscarEmpleado(((ServiciosHasEmpleado) tblServiciosHasEmpleado.getSelectionModel().getSelectedItem()).getCodigoEmpleado()));
        fecha.selectedDateProperty().set(((ServiciosHasEmpleado) tblServiciosHasEmpleado.getSelectionModel().getSelectedItem()).getFechaEvento());
        JFXHoraEvento.setValue(LocalTime.parse(((ServiciosHasEmpleado) tblServiciosHasEmpleado.getSelectionModel().getSelectedItem()).getHoraEvento()));
        txtServicio_LugarEvento.setText(((ServiciosHasEmpleado) tblServiciosHasEmpleado.getSelectionModel().getSelectedItem()).getLugarEvento());
    }
    public ObservableList<ServiciosHasEmpleado> getServiciosHasEmpleado() {
        ArrayList<ServiciosHasEmpleado> lista = new ArrayList<ServiciosHasEmpleado>();

        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("call sp_ListarServicios_has_Empleados()");
            ResultSet resultado = procedimiento.executeQuery();
            while (resultado.next()) {
                lista.add(new ServiciosHasEmpleado(resultado.getInt("Servicios_codigoServicio"),
                        resultado.getInt("codigoServicio"),
                        resultado.getInt("codigoEmpleado"),
                        resultado.getDate("fechaEvento"),
                        resultado.getString("horaEvento"),
                        resultado.getString("lugarEvento")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaServicioHasEmpleado = FXCollections.observableArrayList(lista);
    }
    
    public Servicio buscarServicio(int codigoServicio) {
        Servicio resultado = null;

        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("call sp_BuscarServicio(?)");
            procedimiento.setInt(1, codigoServicio);
            ResultSet registro = procedimiento.executeQuery();
            while (registro.next()) {
                resultado = new Servicio(registro.getInt("codigoServicio"),
                        registro.getDate("fechaServicio"),
                        registro.getString("tipoServicio"),
                        registro.getString("horaServicio"),
                        registro.getString("lugarServicio"),
                        registro.getString("telefonoContacto"),
                        registro.getInt("codigoEmpresa"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return resultado;
    }
    public ObservableList<Servicio> getServicio() {
        ArrayList<Servicio> lista = new ArrayList<Servicio>();

        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall(" call sp_ListarServicios()");
            ResultSet resultado = procedimiento.executeQuery();
            while (resultado.next()) {
                lista.add(new Servicio(resultado.getInt("codigoServicio"),
                        resultado.getDate("fechaServicio"),
                        resultado.getString("tipoServicio"),
                        resultado.getString("horaServicio"),
                        resultado.getString("lugarServicio"),
                        resultado.getString("telefonoContacto"),
                        resultado.getInt("codigoEmpresa")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaHasServicito = FXCollections.observableArrayList(lista);
    }
    
    public Empleado buscarEmpleado(int codigoEmpleado) {
        Empleado resultado = null;

        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("call sp_BuscarEmpleados(?)");
            procedimiento.setInt(1, codigoEmpleado);
            ResultSet registro = procedimiento.executeQuery();
            while (registro.next()) {
                resultado = new Empleado(registro.getInt("CodigoEmpleado"),
                        registro.getInt("numeroEmpleado"),
                        registro.getString("apellidosEmpleado"),
                        registro.getString("nombresEmpleado"),
                        registro.getString("direccionEmpleado"),
                        registro.getString("telefonoContacto"),
                        registro.getString("gradoCocinero"),
                        registro.getInt("codigoTipoEmpleado"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return resultado;
    }
    public ObservableList<Empleado> getEmpleado() {
        ArrayList<Empleado> lista = new ArrayList<>();

        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("Call sp_ListarEmpleados()");
            ResultSet resultado = procedimiento.executeQuery();
            while (resultado.next()) {
                lista.add(new Empleado(resultado.getInt("codigoEmpleado"),
                        resultado.getInt("numeroEmpleado"),
                        resultado.getString("apellidosEmpleado"),
                        resultado.getString("nombresEmpleado"),
                        resultado.getString("direccionEmpleado"),
                        resultado.getString("telefonoContacto"),
                        resultado.getString("gradoCocinero"),
                        resultado.getInt("codigoTipoEmpleado")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaHasEmpleadito = FXCollections.observableArrayList(lista);
    }
    public void nuevo() {
        switch (tipoDeOperacion) {
            case NINGUNO:
                limpiarControles();
                activarControles();
                btnAgregar.setText("Guardar");
                btnReporte.setText("Cancelar");
                imgAgregar.setImage(new Image("/org/pedromedina/image/guardar.png"));
                imgReporte.setImage(new Image("/org/pedromedina/image/cancelar.png"));
                tipoDeOperacion = operaciones.GUARDAR;
                break;
            case GUARDAR:
                guardar();
                limpiarControles();
                desactivarControles();
                btnAgregar.setText("Agregar");
                btnReporte.setText("Listar");
                imgAgregar.setImage(new Image("/org/pedromedina/image/btn+.png"));
                tipoDeOperacion = operaciones.NINGUNO;
                break;
        }
    }

    public void reporte() {
        switch (tipoDeOperacion) {
            case GUARDAR:
                limpiarControles();
                btnAgregar.setText("Agregar");
                btnReporte.setText("Listar");
                imgAgregar.setImage(new Image("/org/pedromedina/images/btn+.png"));
                imgReporte.setImage(new Image("/org/pedromedina/image/btnEliminar.png"));
                tipoDeOperacion = operaciones.NINGUNO;
                break;
        }
    }

    public void guardar() {
        if (txtServicios_codigoServicio.getText().isEmpty() || cmbServicio_codigoServicio.getSelectionModel().getSelectedItem() == null
                || cmbServicio_codigoEmpleado.getSelectionModel().getSelectedItem() == null || fecha.getSelectedDate() == null
                || JFXHoraEvento.getValue() == null || txtServicio_LugarEvento.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Papito, primero rellena todos los datos");
        } else {

            ServiciosHasEmpleado registro = new ServiciosHasEmpleado();
            registro.setServicios_codigoServicio(Integer.parseInt(txtServicios_codigoServicio.getText()));
            registro.setCodigoServicio(((Servicio) cmbServicio_codigoServicio.getSelectionModel().getSelectedItem()).getCodigoServicio());
            registro.setCodigoEmpleado(((Empleado) cmbServicio_codigoEmpleado.getSelectionModel().getSelectedItem()).getCodigoEmpleado());
            registro.setFechaEvento(fecha.getSelectedDate());
            registro.setHoraEvento(String.valueOf(JFXHoraEvento.getValue()));
            registro.setLugarEvento((txtServicio_LugarEvento.getText()));

            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("call sp_AgregarServicios_has_Empleados(?,?,?,?,?,?)");
                procedimiento.setInt(1, registro.getServicios_codigoServicio());
                procedimiento.setInt(2, registro.getCodigoServicio());
                procedimiento.setInt(3, registro.getCodigoEmpleado());
                procedimiento.setDate(4, new java.sql.Date(registro.getFechaEvento().getTime()));
                procedimiento.setString(5, String.valueOf(JFXHoraEvento.getValue()));
                procedimiento.setString(6, registro.getLugarEvento());
                procedimiento.execute();
                listaServicioHasEmpleado.add(registro);
                cargarDatos();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void desactivarControles() {
        txtServicios_codigoServicio.setEditable(false);
        cmbServicio_codigoServicio.setDisable(true);
        cmbServicio_codigoEmpleado.setDisable(true);
        JFXHoraEvento.setDisable(true);
        fecha.setDisable(true);
        txtServicio_LugarEvento.setEditable(false);
    }

    public void activarControles() {
        txtServicios_codigoServicio.setEditable(true);
        cmbServicio_codigoServicio.setDisable(false);
        cmbServicio_codigoEmpleado.setDisable(false);
        JFXHoraEvento.setDisable(false);
        fecha.setDisable(false);
        txtServicio_LugarEvento.setEditable(true);
    }

    public void limpiarControles() {
        txtServicios_codigoServicio.clear();
        cmbServicio_codigoServicio.setValue(null);
        cmbServicio_codigoEmpleado.setValue(null);
        fecha.setSelectedDate(null);
        JFXHoraEvento.setValue(null);
        txtServicio_LugarEvento.clear();
    }

    public Principal getEscenarioPrincipal(){
        return escenarioPrincipal;
    }
    
    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }

}
