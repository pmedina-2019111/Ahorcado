/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.pedromedina.bean;

import java.util.Map;
import java.util.HashMap;
import org.pedromedina.report.GenerarReporte;
/**
 *
 * @author Usuario
 */
public class ReporteGeneral {
    public void imprimirReporte(){
        Map parametros = new HashMap();
        parametros.put("fondinho", this.getClass().getResource("/org/pedromedina/image/fondaco.png"));
        GenerarReporte.mostrarReporte("ReporteGeneral.jasper", "ReporteGeneral", parametros);
        
    }
}
