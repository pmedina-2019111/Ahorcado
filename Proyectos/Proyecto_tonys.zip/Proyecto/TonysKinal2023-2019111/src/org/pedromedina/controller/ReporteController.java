
package org.pedromedina.controller;

import java.util.Map;
import java.util.HashMap;
import org.pedromedina.report.GenerarReporte;

public class ReporteController {
    public void imprimirReporte(){
        Map parametros = new HashMap();
        parametros.put("fondinho", this.getClass().getResource("/org/pedromedina/image/fondaco.png"));
        GenerarReporte.mostrarReporte("ReporteGeneral.jasper", "ReporteGeneral", parametros);
        
    }
}
