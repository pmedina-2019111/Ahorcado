/*
Nombre: Pedro Emilio Medina de Paz
Código Técnico: IN5BM
Carné: 2019111
Fecha de Creación: 28/03/2023 10:55
Fecha de modificaciones: 10/04/2023 15:52
						10/04/2023 19:10
*/
Drop database if exists DBTonysKinal2023;
Create database DBTonysKinal2023;

Use DBTonysKinal2023;

Create table Empresas (
	codigoEmpresa int auto_increment not null,
    nombreEmpresa varchar(150) not null,
    direccion varchar(150) not null,
    telefono varchar(10) not null,
    primary key PK_codigoEmpresa (codigoEmpresa)
);


Create table TipoEmpleado(
	codigoTipoEmpleado int not null auto_increment,
    descripcion varchar(50) not null,
    primary key PK_codigoTipoEmpleado (codigoTipoEmpleado)	
);


Create table Empleados(
	codigoEmpleado int auto_increment not null,
    numeroEmpleado int not null,
    apellidosEmpleado varchar(150) not null,
    nombresEmpleado varchar(150) not null,
    direccionEmpleado varchar(150) not null,
    telefonoContacto varchar(10) not null,
    gradoCocinero varchar(50),
    codigoTipoEmpleado int not null,
    primary key PK_codigoEmpleado (codigoEmpleado),
    constraint FK_Empleados_TipoEmpleado foreign key
		(codigoTipoEmpleado) references TipoEmpleado (codigoTipoEmpleado)
);


Create table TipoPlato(
	codigoTipoPlato int auto_increment not null,
    descripcion varchar(100) not null,
    primary key PK_codigoTipoPlato (codigoTipoPlato)
);


Create table Productos(
	codigoProducto int not null,
    nombreProducto varchar(150) not null,
    cantidad int not null,
    primary key PK_codigoProducto (codigoProducto)
);

Create table Servicios(
	codigoServicio int auto_increment not null,
    fechaServicio date not null,
    tipoServicio varchar(150) not null,
    horaServicio time not null,
    lugarServicio varchar(150) not null,
    telefonoContacto varchar(10) not null,
    codigoEmpresa int not null,
    primary key PK_codigoServicio (codigoServicio),
	constraint FK_Servicio_Empresas foreign key (codigoEmpresa)
		references Empresas (codigoEmpresa)
);


Create table Presupuestos(
	codigoPresupuesto int auto_increment not null,
    fechaSolicitud date not null,
    cantidadPresupuesto decimal(10, 2),
    codigoEmpresa int not null,
    primary key PK_codigoPresupuesto (codigoPresupuesto),
    constraint FK_Presupuestos_Empresas foreign key (codigoEmpresa)
		references Empresas (codigoEmpresa)
);	


Create table Platos(
	codigoPlato int auto_increment not null,
    cantidad int not null,
    nombrePlato varchar(50),
    descripcionPlato varchar(150),
    precioPlato decimal (10,2),
    codigoTipoPlato int not null,
    -- TipoPlato codigoTipoPlato int not null,
    primary key PK_codigoPlato (codigoPlato),
    constraint PK_Platos_TipoPlato1 foreign key (codigoTipoPlato)
		references TipoPlato (codigoTipoPlato)
);


 Create table Productos_has_Platos(
	Productos_codigoProducto int not null,
    codigoPlato	int not null,
    codigoProducto int not null,
    primary key PK_Productos_codigoProducto (Productos_codigoProducto),
    constraint FK_Productos_has_Platos_Productos1 foreign key (codigoProducto)
		references Productos(codigoProducto),
	constraint FK_Productos_has_Platos_Platos1 foreign key (codigoPlato)
		references Platos (codigoPlato)
 );


Create table Servicios_has_Platos(
	Servicios_codigoServicio int not null,
    codigoPlato int not null,
    codigoServicio int not null,
    primary key PK_Servicios_codigoServicio (Servicios_codigoServicio),
	constraint FK_Servicios_has_Platos_Servicios foreign key (codigoServicio)
		references Servicios (codigoServicio),
	constraint FK_Servicios_has_Platos_Platos foreign key (codigoPlato)
		references Platos (codigoPlato)
);


Create table Servicios_has_Empleados(
	Servicios_codigoServicio int not null,
    codigoServicio int not null,
    codigoEmpleado int not null,
    fechaEvento date not null,
    horaEvento time not null,
    lugarEvento varchar(150) not null,
    primary key PK_Servicios_codigoServicio (Servicios_codigoServicio),
    constraint FK_Servicios_has_Empleados_Servicios1 foreign key (codigoServicio)
		references Servicios (codigoServicio),
	constraint FK_Servicios_has_Empleados_Empleados1 foreign key (codigoEmpleado)
		references Empleados (codigoEmpleado)
);

Create table Usuario(
	codigoUsuario int not null auto_increment,
    nombreUsuario varchar(100) not null,
    apellidoUsuario varchar(100) not null,
    usuarioLogin varchar(50) not null,
    contrasena varchar(50) not null,
    primary key PK_codigoUsuario (codigoUsuario)
);

Delimiter $$
	Create procedure sp_AgregarUsuario(in nombreUsuario varchar(100), in apellidoUsuario varchar(100), in usuarioLogin varchar(50), in contrasena varchar(50))
		begin 
			insert into Usuario (nombreUsuario, apellidoUsuario, usuarioLogin, contrasena)
			value (nombreUsuario, apellidoUsuario, usuarioLogin, contrasena);
		End$$
Delimiter ;

call sp_AgregarUsuario('Pedro', 'Medina', 'pmedina', '12345');

Delimiter $$
	Create procedure sp_ListarUsuario()
		Begin
			Select 
				U.codigoUsuario,
                U.nombreUsuario,
                U.apellidoUsuario,
                U.usuarioLogin,
                U.contrasena
			from Usuario U;
		End$$
Delimiter ;

call sp_ListarUsuario();

Create table Login(
	usuarioMaster varchar(50) not null,
    passwordLogin varchar (50) not null,
    primary key PK_usuarioMaster (usuarioMaster)
);
-- Use DBRecuperacion;

-- ---------------- Procedimientos almacenados Entidad Empresas------------------------

-- Agregar Empresas---
Delimiter $$
	Create procedure sp_AgregarEmpresa (in nombreEmpresa varchar(150), in direccion varchar(150), in telefono varchar(10))
		Begin
			Insert into Empresas (nombreEmpresa, direccion, telefono)
				values (nombreEmpresa, direccion, telefono);
        End$$
Delimiter ;

Call sp_AgregarEmpresa ('Campero', 'Guatemala', '12345678');
Call sp_AgregarEmpresa ('Dominos', 'villa nueva', '17405847');
Call sp_AgregarEmpresa ('Pizza hut', 'villa canales', '37916295');

-- Listar Empresas---
-- drop procedure sp_ListarEmpresas;
Delimiter $$
	Create procedure sp_ListarEmpresas ()
		Begin
			Select 	
            E.codigoEmpresa,
            E.nombreEmpresa,
			E.direccion,
            E.telefono
            From Empresas E;
        End$$
Delimiter ;
	
Call sp_ListarEmpresas();

-- Buscar Empresa---
Delimiter $$
	Create procedure sp_BuscarEmpresa (in codEmp int)
		Begin
			Select 
            E.codigoEmpresa,
            E.nombreEmpresa,
			E.direccion,
            E.telefono
            From Empresas E where codigoEmpresa = codEmp;
        End$$
Delimiter ;

Call sp_BuscarEmpresa (2);
Call sp_BuscarEmpresa (5);
Call sp_BuscarEmpresa (1);

-- Eliminar Empresa---
Delimiter $$
	Create procedure sp_EliminarEmpresa (in codEmp int)
		Begin
			Delete from Empresas
					where codigoEmpresa = codEmp;
        End$$
Delimiter ;

-- Call sp_BuscarEmpresa (2);
-- Call sp_BuscarEmpresa (5);
-- Call sp_BuscarEmpresa (1);

-- Editar Empresa---
-- drop procedure sp_EditarEmpresa;
Delimiter $$
	Create procedure sp_EditarEmpresa (in codEmp int, in nomEmp varchar(150), in dir varchar(150), in tel varchar(10))
		Begin
			Update Empresas E
				Set E.codigoEmpresa = codEmp,
					E.nombreEmpresa = nomEmp,
                    E.direccion = dir,
                    E.telefono = tel
                    where E.codigoEmpresa = codEmp;
        End$$
Delimiter ;

-- Call sp_EditarEmpresa (2, 'MacDonalds', 'Antigua Guatemala', '1770');
-- Call sp_EditarEmpresa (5, 'Burger King', 'Jalapa', '1973');
-- Call sp_EditarEmpresa (1, 'Wendys', 'Petén', '1236');

-- -- ---------------- Procedimientos almacenados Entidad TipoEmpleado------------------------
-- Agregar TipoEmpleado---
Delimiter $$
	Create procedure sp_AgregarTipoEmpleado (in descripcion varchar(50))
		Begin
			Insert into TipoEmpleado (descripcion)
				values (descripcion);
        End$$
Delimiter ;

Call sp_AgregarTipoEmpleado ('Jefe de sección');
Call sp_AgregarTipoEmpleado ('Director ejecutivo');
Call sp_AgregarTipoEmpleado ('Administrativo');

-- Listar TipoEmpleados---
-- drop procedure sp_ListarTipoEmpleados;
Delimiter $$
	Create procedure sp_ListarTipoEmpleados ()
		Begin
			Select 
            TP.codigoTipoEmpleado,
            TP.descripcion
            From TipoEmpleado TP;
        End$$
Delimiter ;

Call sp_ListarTipoEmpleados();

-- Buscar TipoEmpleado---
-- drop procedure sp_BuscarTipoEmpleado;
Delimiter $$
	Create procedure sp_BuscarTipoEmpleado (in codTipEmp int)
		Begin
			Select
				TP.codigoTipoEmpleado,
				TP.descripcion
                From TipoEmpleado TP where codigoTipoEmpleado = codTipEmp;
        End$$
Delimiter ;

Call sp_BuscarTipoEmpleado (1);
Call sp_BuscarTipoEmpleado (2);
Call sp_BuscarTipoEmpleado (3); 

-- Eliminar TipoEmpleado---
Delimiter $$
	Create procedure sp_EliminarTipoEmpleado (in codTipEmp int)
		Begin
			Delete from TipoEmpleado
				where codigoTipoEmpleado = codTipEmp;
		End$$
Delimiter ;

-- Call sp_EliminarTipoEmpleado (1);
-- Call sp_EliminarTipoEmpleado (2);
-- Call sp_EliminarTipoEmpleado (3);

-- Editar TipoEmpleado---
Delimiter $$
	Create procedure sp_EditarTipoEmpleado (in codTipEmp int, in descrip varchar(50))
		Begin
			Update TipoEmpleado TP
				Set TP.codigoTipoEmpleado = codTipEmp,
					TP.descripcion = descrip
                    where codigoTipoEmpleado = codTipEmp;
        End$$
Delimiter ;

Call sp_EditarTipoEmpleado (1, 'Analista');
Call sp_EditarTipoEmpleado (2, 'Asistente');
Call sp_EditarTipoEmpleado (3, 'Operador'); 

-- -- ---------------- Procedimientos almacenados Entidad Empleados------------------------
-- Agregar Empleado---
Delimiter $$
	Create procedure sp_AgregarEmpleado (in numeroEmpleado int, in apellidosEmpleado varchar(150), in nombresEmpleado varchar(150), in direccionEmpleado varchar(150),
											in telefonoContacto varchar(50), in gradoCocinero varchar(50), in codigoTipoEmpleado int)
		Begin
			Insert Into Empleados (numeroEmpleado, apellidosEmpleado, nombresEmpleado, direccionEmpleado, telefonoContacto, gradoCocinero, codigoTipoEmpleado)
					values (numeroEmpleado, apellidosEmpleado, nombresEmpleado, direccionEmpleado, telefonoContacto, gradoCocinero, codigoTipoEmpleado);
        End$$
Delimiter ;

Call sp_AgregarEmpleado (1615, 'Solis Vega', 'Mario Alberto', 'Zona 7 6ta Av', '2536-8876', 'Chef de Cocina', 3);
Call sp_AgregarEmpleado (1616, 'Herrera Sanchez', 'Roberto Emilio', 'Zona 9 5ta Av', '3890-7662', 'Ayudante de Cocina', 2);
Call sp_AgregarEmpleado (1617, 'Fernández Lara', 'Ana Juliana', 'Zona 3 10ma Av', '1022-3425', 'Cocinero Senior', 1);

-- Listar Empleados---
Delimiter $$
	Create procedure sp_ListarEmpleados ()
		Begin
			Select 
			EM.codigoEmpleado,
            EM.numeroEmpleado,
            EM.apellidosEmpleado,
            EM.nombresEmpleado,
            EM.direccionEmpleado,
            EM.telefonoContacto,
            EM.gradoCocinero,
            EM.codigoTipoEmpleado
            From Empleados EM;
        End$$
Delimiter ;

Call sp_ListarEmpleados ();

-- Buscar Empleado---
-- drop procedure sp_BuscarEmpleado;
Delimiter $$
	Create procedure sp_BuscarEmpleado (in codeEmp int)
		Begin
			Select 	
            EM.codigoEmpleado,
            EM.numeroEmpleado,
            EM.apellidosEmpleado,
            EM.nombresEmpleado,
            EM.direccionEmpleado,
            EM.telefonoContacto,
            EM.gradoCocinero
            From Empleados EM where codigoEmpleado = codeEmp;
		End$$
Delimiter ;

Call sp_BuscarEmpleado (1);
Call sp_BuscarEmpleado (2);
Call sp_BuscarEmpleado (3);

-- Eliminar Empleado---
Delimiter $$
	Create procedure sp_EliminarEmpleado (in codeEmp int)
		Begin
			Delete from Empleados 
				where codigoEmpleado = codeEmp;
        End$$
Delimiter ;

-- Call sp_EliminarEmpleado (1);
-- Call sp_EliminarEmpleado (2);
-- Call sp_EliminarEmpleado (3);

-- Editar Empleado---
-- drop procedure sp_EditarEmpleado;
Delimiter $$
	Create procedure sp_EditarEmpleado (in codeEmp int, in numEmp int, in apeEmp varchar(150), in nomeEmp varchar(150), in direEmp varchar(150), 
											in telCon varchar(10), in graCoc varchar(50), in codTipEmp int)
		Begin
			Update Empleados EM
					Set EM.codigoEmpleado = codeEmp,
						EM.numeroEmpleado = numEmp,
                        EM.apellidosEmpleado = apeEmp,
                        EM.nombresEmpleado = nomeEmp,
                        EM.direccionEmpleado = direEmp,
                        EM.telefonoContacto = telCon,
                        EM.gradoCocinero = graCoc,
                        EM.codigoTipoEmpleado = codTipEmp
                        where codigoEmpleado = codeEmp;
        End$$
Delimiter ;

Call sp_EditarEmpleado (1, '1635', 'Rodríguez Zetino', 'Jorge Nicolás', 'Mixco', '4212-2673', 'Cocinero junior', 2);
Call sp_EditarEmpleado (2, '1665', 'Marlon Andrés', 'Muñiz Leiva', 'Zona 9 7ta av', '3028-5063', 'Ayudante de cocina', 2);
Call sp_EditarEmpleado (3, '1680', 'Maynor Alejandro', 'Caballeros Cruz', 'Zona 6ta av', '1355-9966', 'Cocinero intermedio', 3);

-- -- ---------------- Procedimientos almacenados Entidad TipoPlato------------------------
-- Agregar TipoPlato---
Delimiter $$
	Create procedure sp_AgregarTipoPlato (in descripcion varchar(50))
		Begin
			Insert into TipoPlato (descripcion)
					values (descripcion);
        End$$
Delimiter ;

Call sp_AgregarTipoPlato('Entrada');
Call sp_AgregarTipoPlato('Postre');
Call sp_AgregarTipoPlato('Guarnición');

-- Listar TipoPlatos---
Delimiter $$
	Create procedure sp_ListarTipoPlatos ()
		Begin
			Select 
            T.codigoTipoPlato,
            T.descripcion
            From TipoPlato T;
        End$$
Delimiter ;

Call sp_ListarTipoPlatos ();

-- Buscar TipoPlato---
Delimiter $$
	Create procedure sp_BuscarTipoPlato (in codTipPlat int)
		Begin
			Select
			T.codigoTipoPlato,
            T.descripcion
            From TipoPlato T where codigoTipoPlato = codTipPlat;
        End$$
Delimiter ;

Call sp_BuscarTipoPlato (1);
Call sp_BuscarTipoPlato (2);
Call sp_BuscarTipoPlato (3);

-- Eliminar TipoPlato---
Delimiter $$
	Create procedure sp_EliminarTipoPlato (in codTipPlat int)
		Begin
			Delete from TipoPlato 
				where codigoTipoPlato = codTipPlat;
        End$$
Delimiter ;	

-- Call sp_EliminarTipoPlato (1);
-- Call sp_EliminarTipoPlato (2);
-- Call sp_EliminarTipoPlato (3);

-- Editar TipoPlato---
-- drop procedure sp_EditarTipoPlato;
Delimiter $$
	Create procedure sp_EditarTipoPlato (in codTipPlat int, in descrip varchar(50))
		Begin
			Update TipoPlato T
				Set T.codigoTipoPlato = codTipPlat,
					T.descripcion = descrip
                    where codigoTipoPlato = codTipPlat;
        End$$	
Delimiter ;

Call sp_EditarTipoPlato (1, 'Mexicano');
Call sp_EditarTipoPlato (2, 'Argentino');
Call sp_EditarTipoPlato (3, 'Italiano');

-- -- ---------------- Procedimientos almacenados Entidad Productos------------------------
-- Agregar Producto---
-- drop procedure sp_AgregarProducto;
Delimiter $$
	Create procedure sp_AgregarProducto (in codigoProducto int, in nombreProducto varchar(150), in cantidad int)
		Begin
			Insert into Productos (codigoProducto, nombreProducto, cantidad)
					values (codigoProducto, nombreProducto, cantidad);
        End$$
Delimiter ;

Call sp_AgregarProducto(1500, 'Quesoburguesa', 15);
Call sp_AgregarProducto(1501, 'Bife con chorizo', 32);
Call sp_AgregarProducto(1502, 'Ceviche Mixto', 20);

-- Listar Productos---
Delimiter $$
	Create procedure sp_ListarProductos ()
		Begin	
			Select 
            P.codigoProducto,
            P.nombreProducto,
            P.cantidad
            From Productos P;
        End$$
Delimiter ;

Call sp_ListarProductos ();

-- Buscar Producto---
Delimiter $$
	Create procedure sp_BuscarProducto (in codProd int)
		Begin
			Select 
			P.codigoProducto,
            P.nombreProducto,
            P.cantidad
            From Productos P where codigoProducto = codProd;
        End$$
Delimiter ;

Call sp_BuscarProducto(1500);
Call sp_BuscarProducto(1501);
Call sp_BuscarProducto(1502);

-- Eliminar Producto---
Delimiter $$
	Create procedure sp_EliminarProducto (in codProd int)
		Begin 
			Delete from Productos 
				where codigoProducto = codProd;
        End$$
Delimiter ;

-- Call sp_EliminarProducto(1500);
-- Call sp_EliminarProducto(1501);
-- Call sp_EliminarProducto(1502);

-- Editar Producto---
Delimiter $$
	Create procedure sp_EditarProducto (in codProd int, in nomProd varchar(150), in cant int)
		Begin
			Update Productos P
				Set P.codigoProducto = codProd,
					P.nombreProducto = nomProd,
                    P.cantidad = cant
                    where codigoProducto = codProd;
        End$$
Delimiter ;

Call sp_EditarProducto (1500, 'Cuarto de libra', 43);
Call sp_EditarProducto (1501, 'Milanesa con pure de papas', '56');
Call sp_EditarProducto (1502, 'Mate', '38');

-- -- ---------------- Procedimientos almacenados Entidad Servicios-----------------------
-- Agregar Servicio---
Delimiter $$
	Create procedure sp_AgregarServicio (in fechaServicio date, in tipoServicio varchar(150), in horaServicio time, in lugarServicio varchar(150),
											in telefonoContacto varchar(10), in codigoEmpresa int)
		Begin
			Insert into Servicios (fechaServicio, tipoServicio, horaServicio, lugarServicio, telefonoContacto, codigoEmpresa)
					values (fechaServicio, tipoServicio, horaServicio, lugarServicio, telefonoContacto, codigoEmpresa);
        End$$
Delimiter ;

Call sp_AgregarServicio ('2023-03-23', 'domicilio', now(), 'Dominos', '4789-3452', 1);
Call sp_AgregarServicio ('2023-04-22', 'domicilio', now(), 'TacoBell', '1608-0402', 2);
Call sp_AgregarServicio ('2023-01-23', 'domicilio', now(), 'Lai Lai', '1564-0091', 3);

-- Listar Servicios---
Delimiter $$
	Create procedure sp_ListarServicios ()
		Begin
			Select 
				S.codigoServicio,
                S.fechaServicio,
                S.tipoServicio,
                S.horaServicio,
                S.lugarServicio,
                S.telefonoContacto,
                S.codigoEmpresa
                From Servicios S;
        End$$
Delimiter ;

Call sp_ListarServicios ();

-- Buscar Servicio---
Delimiter $$
	Create procedure sp_BuscarServicio (in codSer int)
		Begin
			Select 
            S.codigoServicio,
			S.fechaServicio,
			S.tipoServicio,
            S.horaServicio,
			S.lugarServicio,
			S.telefonoContacto,
			S.codigoEmpresa
			From Servicios S where codigoServicio = codSer;
        End$$
Delimiter ;

Call sp_BuscarServicio (1);
Call sp_BuscarServicio (2);
Call sp_BuscarServicio (3);

-- Eliminar Servicio---
Delimiter $$
	Create procedure sp_EliminarServicio (in codSer int)
		Begin
			Delete from Servicios 
				where codigoServicio = codSer;
        End$$
Delimiter ;

-- Call sp_EliminarServicio (1);
-- Call sp_EliminarServicio (2);
-- Call sp_EliminarServicio (3);

-- Editar Servicio---
Delimiter $$
	Create procedure sp_EditarServicio (in codSer int, in fecSer date, in tipSer varchar(150), in horSer time, in lugar varchar(150),
											in telCon varchar(10), in codEmp int)
		Begin
			Update Servicios S
				Set S.codigoServicio = codSer,
					S.fechaServicio = fecSer,
                    S.tipoServicio = tipSer,
                    S.horaServicio = horSer,
                    S.lugarServicio = lugar,
                    S.telefonoContacto = telCon,
                    S.codigoEmpresa = codEmp
                    where codigoServicio = codSer;
        End$$
Delimiter ;

Call sp_EditarServicio (1, '10-03-23', 'domicilio', now(), 'Escuintla', '2444-5133', 1);
Call sp_EditarServicio (2, '16-02-23', 'Página web', '18:15', 'Chuiquimula', '4590-6030', 2);
Call sp_EditarServicio (3, '15-05-18', 'Aplicación', '15:30', 'Quiche', '5563-3484', 3);


-- -- ---------------- Procedimientos almacenados Entidad Presupuesto-----------------------
-- Agregar Presupuesto---
Delimiter $$
	Create procedure sp_AgregarPresupuesto (in fechaSolicitud date, in cantidadPresupuesto decimal(10,2), in codigoEmpresa int)
		Begin
			Insert into Presupuestos (fechaSolicitud, cantidadPresupuesto, codigoEmpresa)
					values (fechaSolicitud, cantidadPresupuesto, codigoEmpresa);
        End$$
Delimiter ;

Call sp_AgregarPresupuesto ('08-02-23', '5360.00', 1);
Call sp_AgregarPresupuesto ('01-01-23', '1575.00', 2);
Call sp_AgregarPresupuesto ('20-03-22', '10500.00', 3);

-- Listar Presupuestos---
Delimiter $$
	Create procedure sp_ListarPresupuestos ()
		Begin
			Select 
            PR.codigoPresupuesto,
            PR.fechaSolicitud,
            PR.cantidadPresupuesto,
            PR.codigoEmpresa
            From Presupuestos PR;
        End$$
Delimiter ;

Call sp_ListarPresupuestos ();

-- Buscar Presupuestos---
Delimiter $$
	Create procedure sp_BuscarPresupuestos (in codPre int)
		Begin
			Select 
            PR.codigoPresupuesto,
            PR.fechaSolicitud,
            PR.cantidadPresupuesto,
            PR.codigoEmpresa
            From Presupuestos PR where codigoPresupuesto = codPre;
        End$$
Delimiter ;

Call sp_BuscarPresupuestos(1);
Call sp_BuscarPresupuestos(2);
Call sp_BuscarPresupuestos(3);

-- Eliminar Presupuestos---
Delimiter $$
	Create procedure sp_EliminarPresupuesto (in codPre int)
		Begin
			Delete from Presupuestos 
				where codigoPresupuesto = codPre;
        End$$
Delimiter ;

-- Call sp_EliminarPresupuesto(1);
-- Call sp_EliminarPresupuesto(2);
-- Call sp_EliminarPresupuesto(3);

-- Editar Presupuesto---
Delimiter $$
	Create procedure sp_EditarPresupuesto (in codPre int, in fecSol date, in canPre decimal(10,2), in codEm int)
		Begin
			Update Presupuestos PR
				Set PR.codigoPresupuesto = codPre,
					PR.fechaSolicitud = fecSol,
                    PR.cantidadPresupuesto = canPre,
                    PR.codigoEmpresa = codEm
                    where codigoPresupuesto = codPre;
        End$$
Delimiter ;

Call sp_EditarPresupuesto (1, '12-12-22', '7225.00', 3);
Call sp_EditarPresupuesto (2, '14-06-21', '8960.00', 2);
Call sp_EditarPresupuesto (1, '04-04-15', '5430.00', 1);

-- -- ---------------- Procedimientos almacenados Entidad Platos-----------------------
-- Agregar Plato---
Delimiter $$
	Create procedure sp_AgregarPlato (in cantidad int, in nombrePlato varchar(50), in descripcionPlato varchar(150),
										in precioPlato decimal(10,2), in codigoTipoPlato int)
	Begin
		Insert Into Platos (cantidad, nombrePlato, descripcionPlato, precioPlato, codigoTipoPlato)
				values (cantidad, nombrePlato, descripcionPlato, precioPlato, codigoTipoPlato);
    End$$
Delimiter ;

Call sp_AgregarPlato (3, 'Tacos de carne asada', 'tortillas de maíz rellenas de carne asada, cebolla y cilantro, servidas con salsa y limones', '60.00', 1);
                        
Call sp_AgregarPlato (1, 'Lasaña de carne', 'pasta con salsa de carne, queso ricotta y mozzarella gratinado al horno', '125.00', 2);
                        
Call sp_AgregarPlato (2, 'Bife de chorizo', 'un corte de carne de res argentino que se sirve generalmente con papas fritas y ensalada', '75.50', 3);
                        
-- Listar Platos---
Delimiter $$
	Create procedure sp_ListarPlatos ()
		Begin
			Select 
            PL.codigoPlato,
            PL.cantidad,
            PL.nombrePlato,
            PL.descripcionPlato,
            PL.precioPlato,
            PL.codigoTipoPlato
            From Platos PL;
        End$$
Delimiter ;

Call sp_ListarPlatos ();

-- Buscar Plato---
Delimiter $$
	Create procedure sp_BuscarPlato (in codPlat int)
		Begin
			Select 
            PL.codigoPlato,
            PL.cantidad,
            PL.nombrePlato,
            PL.descripcionPlato,
            PL.precioPlato,
            PL.codigoTipoPlato
            From Platos PL where codigoPlato = codPlat;
        End$$
Delimiter ;

Call sp_BuscarPlato (1);
Call sp_BuscarPlato (2);
Call sp_BuscarPlato (3);

-- Eliminar Plato---
Delimiter $$
	Create procedure sp_EliminarPlato (in codPlat int)
		Begin
			Delete from Platos 
				where codigoPlato = codPlat;
        End$$
Delimiter ;

-- Call sp_EliminarPlato (1);
-- Call sp_EliminarPlato (2);
-- Call sp_EliminarPlato (3);

-- Editar Plato---
Delimiter $$
	Create procedure sp_EditarPlato (in codPlat int, in can int, in nomPlat varchar(50),
										in descripPlato varchar(150), in prePl decimal(10,2), in codTiPl int)
		Begin
			Update Platos PL
				Set PL.codigoPlato = codPlat,
					PL.cantidad = can, 
                    PL.nombrePlato = nomPlat,
                    PL.descripcionPlato = descripPlato,
                    PL.precioPlato = prePl,
                    Pl.codigoTipoPlato = codTiPl
                    where codigoPlato = codPlat;
        End$$
Delimiter ;

Call sp_EditarPlato (1, 5, 'Pizza margherita', 'una pizza clásica italiana hecha con salsa de tomate, mozzarella fresca y hojas de albahaca', 175.00, 2);
Call sp_EditarPlato (2, 7, 'Enchiladas verdes con arroz y frijoñes', 'tortillas de maíz rellenas de pollo, cubiertas con salsa verde y queso, servidas con arroz y frijoles', 55.00, 1);
Call sp_EditarPlato (3, 3, 'Empanadas de carne', 'empanadas rellenas de carne de res, cebolla y pimiento, servidas con salsa criolla', 35.00, 3);

-- -- ---------------- Procedimientos almacenados Entidad Productos_has_Platos----------------------
-- Agregar Productos_has_Platos---
Delimiter $$
	Create procedure sp_AgregarProductos_has_Platos (in Productos_codigoProducto int, in codigoPlato int, in codigoProducto int)
		Begin
			Insert into Productos_has_Platos (Productos_codigoProducto, codigoPlato, codigoProducto)
					values (Productos_codigoProducto, codigoPlato, codigoProducto);
        End$$
Delimiter ;

-- select codigoProducto from Productos;
-- select * from Productos;
-- select codigoPlato from Platos;
Call sp_AgregarProductos_has_Platos (1, 1, 1500);
Call sp_AgregarProductos_has_Platos (2, 2, 1501);
Call sp_AgregarProductos_has_Platos (3, 3, 1502);

-- Listar Productos_has_Platos---
Delimiter $$
	Create procedure sp_ListarProductos_has_Platos ()
		Begin
			Select
            Productos_codigoProducto,
            codigoPlato,
            codigoProducto
            From Productos_has_Platos;
        End$$
Delimiter ;

Call sp_ListarProductos_has_Platos ();

-- Buscar Productos_has_Platos---
Delimiter $$
	Create procedure sp_BuscarProducto_has_Platos (in cprod int)
		Begin
			Select 
            Productos_codigoProducto,
            codigoPlato,
            codigoProducto
            From Productos_has_Platos where Productos_codigoProducto = cprod;
		End$$
Delimiter ;

Call sp_BuscarProducto_has_Platos (1);
Call sp_BuscarProducto_has_Platos (2);
Call sp_BuscarProducto_has_Platos (3);

-- Eliminar Productos_has_Platos---
Delimiter $$
	Create procedure sp_EliminarProductos_has_Platos (in cprod int)
		Begin
			Delete from Productos_has_Platos
				where Productos_codigoProducto = cprod;
        End$$
Delimiter ;


-- Editar Producto_has_Platos---
Delimiter $$
	Create procedure sp_EditarProducto_has_Platos (in cprod int, in cplat int, in cp int)
		Begin
			Update Productos_has_Platos CP
				Set CP.Productos_codigoProducto = cprod,
					CP.codigoPlato = cplat,
                    CP.codigoProducto = cp
                    where Productos_codigoProducto = cprod;
        End$$
Delimiter ;

-- Call sp_EditarProducto_has_Platos (4, 3, 2);
-- Call sp_EditarProducto_has_Platos (5, 1, 3);
-- Call sp_EditarProducto_has_Platos (6, 2, 1);

-- -- ---------------- Procedimientos almacenados Entidad Servicios_has_Platos----------------------
-- Agregar Servicio_has_Platos---
Delimiter $$
	Create procedure sp_AgregarServicio_has_Platos (in Servicios_codigoServicio int, in codigoPlato int, in codigoServicio int)
		Begin
			Insert into Servicios_has_Platos (Servicios_codigoServicio, codigoPlato, codigoServicio)
					values (Servicios_codigoServicio, codigoPlato, codigoServicio);
        End$$
Delimiter ;

Call sp_AgregarServicio_has_Platos (1, 3, 1);
Call sp_AgregarServicio_has_Platos (2, 2, 3);
Call sp_AgregarServicio_has_Platos (3, 1, 2);

-- Listar Servicio_Has_Platos---
Delimiter $$
	Create procedure sp_ListarServicios_has_Platos ()
		Begin
			Select 
            Servicios_codigoServicio,
            codigoPlato,
            codigoServicio
            from Servicios_has_Platos;
        End$$
Delimiter ;

Call sp_ListarServicios_has_Platos ();

-- Buscar Servicio_has_Platos---
Delimiter $$
	Create procedure sp_BuscarServicio_has_Platos (in seco int)
		Begin
			Select 
            Servicios_codigoServicio,
            codigoPlato,
            codigoServicio
            from Servicios_has_Platos where Servicios_codigoServicio = seco;
        End$$
Delimiter ;

Call sp_BuscarServicio_has_Platos (2);
Call sp_BuscarServicio_has_Platos (3);
Call sp_BuscarServicio_has_Platos (1);

-- Eliminar Servicio_has_Platos---
Delimiter $$
	Create procedure sp_EliminarServicio_has_Platos (in seco int)
		Begin
			Delete from Servicios_has_Platos 
				where Servicios_codigoServicio = seco;
		End$$
Delimiter ;

-- Call sp_EliminarServicio_has_Platos (1);
-- Call sp_EliminarServicio_has_Platos (2);
-- Call sp_EliminarServicio_has_Platos (3);

-- Editar Servicio_has_Platos---
Delimiter $$
	Create procedure sp_EditarServicio_has_Platos (in seco int, in cop int, in cos int)
		Begin
			Update Servicios_has_Platos SE
				Set SE.Servicios_codigoServicio = seco,
					SE.codigoPlato = cop,
                    SE.codigoServicio = cos
                    where Servicios_codigoServicio = seco;
        End$$
Delimiter ;

Call sp_EditarServicio_has_Platos (3, 3, 1);
Call sp_EditarServicio_has_Platos (2, 2, 2);
Call sp_EditarServicio_has_Platos (1, 1, 3);

-- -- ---------------- Procedimientos almacenados Entidad Servicios_has_Empleados----------------------
-- Agregar Servicios_has_Empleados---
Delimiter $$
	Create procedure sp_AgregarServicio_has_Empleados (in Servicios_codigoServicio int, in codigoServicio int, in codigoEmpleado int, in fechaEvento date, 
														in horaEvento time, in lugarEvento varchar(150))
		Begin
			Insert into Servicios_has_Empleados (Servicios_codigoServicio, codigoServicio, codigoEmpleado, fechaEvento, horaEvento, lugarEvento)
					values (Servicios_codigoServicio, codigoServicio, codigoEmpleado, fechaEvento, horaEvento, lugarEvento);
        End$$
Delimiter ;

Call sp_AgregarServicio_has_Empleados (1, 1, 1, '09-04-23', now(), 'Zona 7 calle B lote 143');
Call sp_AgregarServicio_has_Empleados (2, 2, 2, '10-04-23', now(), 'Zona 7 calle B lote 143');
Call sp_AgregarServicio_has_Empleados (3, 3, 3, '11-04-23', now(), 'Zona 7 calle B lote 143');

-- Listar Servicios_has_Empleados---
Delimiter $$
	Create procedure sp_ListarServicios_has_Empleados ()
		Begin
			Select 
            Servicios_codigoServicio,
            codigoServicio,
            codigoEmpleado,
            fechaEvento,
            horaEvento,
            lugarEvento
            from Servicios_has_Empleados;
        End$$
Delimiter ;

Call sp_ListarServicios_has_Empleados ();

-- Buscar Servicios_has_Empleados---
Delimiter $$
	Create procedure sp_BuscarServicio_has_Empleados (in Secos int)
		Begin
			Select
            Servicios_codigoServicio,
            codigoServicio,
            codigoEmpleado,
            fechaEvento,
            horaEvento,
            lugarEvento
            from Servicios_has_Empleados where Servicios_codigoServicio = Secos;
        End$$
Delimiter ;

Call sp_BuscarServicio_has_Empleados (1);
Call sp_BuscarServicio_has_Empleados (2);
Call sp_BuscarServicio_has_Empleados (3);

-- Eliminar Servicio_has_Empleados---
Delimiter $$
	Create procedure sp_EliminarServicio_has_Empleados (in Secos int)
		Begin
			Delete from Servicios_has_Empleados
				where Servicios_codigoServicio = Secos;
        End$$
Delimiter ;

-- Call sp_EliminarServicio_has_Empleados (1);
-- Call sp_EliminarServicio_has_Empleados (2);
-- Call sp_EliminarServicio_has_Empleados (3);

-- Editar Servicio_has_Empleados
Delimiter $$
	Create procedure sp_EditarServicio_has_Empleados (in Secos int, in cose int, in codem int, in fev date, in hev time, in lev varchar(150))
		Begin
			Update Servicios_has_Empleados SH
				Set SH.Servicios_codigoServicio = Secos,
					SH.codigoServicio = cose,
                    SH.codigoEmpleado = codem,
                    SH.fechaEvento = fev,
                    SH.horaEvento = hev,
                    SH.lugarEvento = lev
                    where Servicios_codigoServicio = Secos;
        End$$
Delimiter ;

Call sp_EditarServicio_has_Empleados (1, 1, 1, '24-04-23', '10:00', 'Mixco calle A lote 246');
Call sp_EditarServicio_has_Empleados (2, 2, 2, '30-04-23', '16:00', 'Zona 3 calle b 6ta Av Lote 143');
Call sp_EditarServicio_has_Empleados (3, 3, 3, '04-05-23', '06:00', 'Colonia Lupita 6ta Av Calle B');



Delimiter $$
	Create procedure sp_InnerJoins1()
		Begin
			Select E.codigoEmpresa as 'Código de la Empresa',
				   E.nombreEmpresa as 'Nombre de la Empresa',
				   E.direccion as 'Direccción de la Empresa',
                   S.codigoServicio as 'Código del Servicio',
				   S.fechaServicio as 'Fecha del Servicio',
				   S.horaServicio as 'Hora del Servicio',
				   S.lugarServicio as 'Lugar del Servicio',
				   S.telefonoContacto as 'Teléfono Contacto',
                   SE.fechaEvento as 'Fecha del Evento',
				   SE.horaEvento as 'Hora del Evento',
                   Em.nombresEmpleado as 'Nombres del Empleado',
				   Em.apellidosEmpleado as 'Apellidos del Empleado',
				   Em.direccionEmpleado as 'Dirección del Empleado',
				   Em.codigoEmpleado as 'Código del Empleado',
                   TE.descripcion as 'Descripción del Empleado',
				   SP.codigoPlato as 'Código del Plato',
				   SP.codigoServicio as 'Código del Servicio',
                   Pla.cantidad as 'Cantidad del Plato',
				   Pla.nombrePlato as 'Nombre del Plato',
				   Pla.descripcionPlato as 'Descripción del Plato',
				   TP.descripcion as 'Descripción del Tipo de Plato',
                   PP.codigoProducto as 'Código del Producto',
                   P.nombreProducto as 'Nombre del Producto',
				   P.cantidad as 'Cantidad de Producto'
                   
			from Empresas E Inner Join Presupuestos Pre on E.codigoEmpresa = Pre.codigoEmpresa
            Inner Join Servicios S on S.codigoEmpresa = E.codigoEmpresa
            Inner Join Servicios_has_Empleados SE on SE.codigoServicio = S.codigoServicio
            Inner Join Empleados Em on Em.codigoEmpleado = SE.codigoEmpleado
            Inner Join TipoEmpleado TE on TE.codigoTipoEmpleado = Em.codigoTipoEmpleado
            Inner Join Servicios_has_Platos SP on SP.codigoServicio = S.codigoServicio
            Inner Join Platos Pla on Pla.codigoPlato = SP.codigoPlato
            Inner Join TipoPlato TP on TP.codigoTipoPlato = Pla.codigoTipoPlato
            Inner Join Productos_has_Platos PP on Pla.codigoPlato = PP.codigoPlato
            Inner Join Productos P on P.codigoProducto = PP.codigoProducto ; 
           
        End $$
Delimiter ;
call sp_InnerJoins1();